#include "netplay.h"

#include <string.h>

#include "main/device.h"
#include "main/main.h"
#include "r4300/cp0.h"
#include "r4300/cp1.h"
#include "r4300/r4300_core.h"
#include "rsp/rsp_core.h"

extern unsigned char savestate_buffer[NETPLAY_STATE_BUFFER_SIZE];
extern int savestates_load_m64p(const unsigned char* data, size_t size);
extern int savestates_save_m64p(unsigned char* data, size_t size);

static int frame_active;
static uint64_t state_hash;
static uint64_t rdram_hash;
static uint64_t cpu_hash;
static uint64_t rsp_hash;

/* xxHash64, kept private so the fingerprint implementation can be replaced
 * without changing the browser protocol. */
#define XXH_PRIME64_1 UINT64_C(11400714785074694791)
#define XXH_PRIME64_2 UINT64_C(14029467366897019727)
#define XXH_PRIME64_3 UINT64_C(1609587929392839161)
#define XXH_PRIME64_4 UINT64_C(9650029242287828579)
#define XXH_PRIME64_5 UINT64_C(2870177450012600261)

static uint64_t rotl64(uint64_t value, unsigned count)
{
    return (value << count) | (value >> (64 - count));
}

static uint64_t read64(const void* source)
{
    uint64_t value;
    memcpy(&value, source, sizeof(value));
    return value;
}

static uint32_t read32(const void* source)
{
    uint32_t value;
    memcpy(&value, source, sizeof(value));
    return value;
}

static uint64_t xxh64_round(uint64_t accumulator, uint64_t input)
{
    accumulator += input * XXH_PRIME64_2;
    accumulator = rotl64(accumulator, 31);
    accumulator *= XXH_PRIME64_1;
    return accumulator;
}

static uint64_t xxh64_merge_round(uint64_t accumulator, uint64_t value)
{
    value = xxh64_round(0, value);
    accumulator ^= value;
    return accumulator * XXH_PRIME64_1 + XXH_PRIME64_4;
}

static uint64_t xxh64(const void* input, size_t length, uint64_t seed)
{
    const uint8_t* cursor = (const uint8_t*)input;
    const uint8_t* end = cursor + length;
    uint64_t hash;

    if (length >= 32)
    {
        const uint8_t* limit = end - 32;
        uint64_t v1 = seed + XXH_PRIME64_1 + XXH_PRIME64_2;
        uint64_t v2 = seed + XXH_PRIME64_2;
        uint64_t v3 = seed;
        uint64_t v4 = seed - XXH_PRIME64_1;

        do
        {
            v1 = xxh64_round(v1, read64(cursor)); cursor += 8;
            v2 = xxh64_round(v2, read64(cursor)); cursor += 8;
            v3 = xxh64_round(v3, read64(cursor)); cursor += 8;
            v4 = xxh64_round(v4, read64(cursor)); cursor += 8;
        } while (cursor <= limit);

        hash = rotl64(v1, 1) + rotl64(v2, 7) +
               rotl64(v3, 12) + rotl64(v4, 18);
        hash = xxh64_merge_round(hash, v1);
        hash = xxh64_merge_round(hash, v2);
        hash = xxh64_merge_round(hash, v3);
        hash = xxh64_merge_round(hash, v4);
    }
    else
    {
        hash = seed + XXH_PRIME64_5;
    }

    hash += length;

    while (cursor + 8 <= end)
    {
        uint64_t value = xxh64_round(0, read64(cursor));
        hash ^= value;
        hash = rotl64(hash, 27) * XXH_PRIME64_1 + XXH_PRIME64_4;
        cursor += 8;
    }

    if (cursor + 4 <= end)
    {
        hash ^= (uint64_t)read32(cursor) * XXH_PRIME64_1;
        hash = rotl64(hash, 23) * XXH_PRIME64_2 + XXH_PRIME64_3;
        cursor += 4;
    }

    while (cursor < end)
    {
        hash ^= (uint64_t)(*cursor++) * XXH_PRIME64_5;
        hash = rotl64(hash, 11) * XXH_PRIME64_1;
    }

    hash ^= hash >> 33;
    hash *= XXH_PRIME64_2;
    hash ^= hash >> 29;
    hash *= XXH_PRIME64_3;
    hash ^= hash >> 32;
    return hash;
}

struct canonical_cpu_state
{
    int64_t regs[32];
    int64_t hi;
    int64_t lo;
    uint32_t cp0[CP0_REGS_COUNT];
    int64_t cp1[32];
    uint32_t fcr0;
    uint32_t fcr31;
    uint32_t pc;
    uint32_t next_interrupt;
    uint32_t llbit;
    uint32_t vi_next;
    uint32_t vi_field;
};

static uint64_t hash_cpu_state(void)
{
    struct canonical_cpu_state cpu;
    memset(&cpu, 0, sizeof(cpu));
    memcpy(cpu.regs, r4300_regs(), sizeof(cpu.regs));
    memcpy(cpu.cp0, r4300_cp0_regs(), sizeof(cpu.cp0));
    memcpy(cpu.cp1, r4300_cp1_regs(), sizeof(cpu.cp1));
    cpu.hi = *r4300_mult_hi();
    cpu.lo = *r4300_mult_lo();
    cpu.fcr0 = *r4300_cp1_fcr0();
    cpu.fcr31 = *r4300_cp1_fcr31();
    cpu.pc = *r4300_pc();
    cpu.next_interrupt = *r4300_next_interrupt();
    cpu.llbit = *r4300_llbit();
    cpu.vi_next = g_dev.vi.next_vi;
    cpu.vi_field = g_dev.vi.field;
    return xxh64(&cpu, sizeof(cpu), UINT64_C(0x4e36344350550001));
}

static uint64_t hash_rsp_state(void)
{
    uint64_t parts[3];
    parts[0] = xxh64(g_dev.sp.mem, sizeof(g_dev.sp.mem),
                     UINT64_C(0x4e36345253500001));
    parts[1] = xxh64(g_dev.sp.regs, sizeof(g_dev.sp.regs),
                     UINT64_C(0x4e36345253500002));
    parts[2] = xxh64(g_dev.sp.regs2, sizeof(g_dev.sp.regs2),
                     UINT64_C(0x4e36345253500003));
    return xxh64(parts, sizeof(parts), UINT64_C(0x4e36345253500004));
}

size_t retro_serialize_size(void)
{
    return NETPLAY_STATE_BUFFER_SIZE;
}

bool retro_serialize(void* data, size_t size)
{
    if (data == NULL || size < retro_serialize_size())
        return 0;
    return savestates_save_m64p((unsigned char*)data, size) != 0;
}

bool retro_unserialize(const void* data, size_t size)
{
    if (data == NULL || size != retro_serialize_size())
        return 0;
    return savestates_load_m64p((const unsigned char*)data, size) != 0;
}

uint32_t netplay_get_state_size(void)
{
    return (uint32_t)retro_serialize_size();
}

uintptr_t netplay_get_state_buffer(void)
{
    return (uintptr_t)savestate_buffer;
}

int netplay_serialize_state(void)
{
    if (frame_active)
        return 0;
    if (!retro_serialize(savestate_buffer, sizeof(savestate_buffer)))
        return 0;
    netplay_refresh_state_hash();
    return 1;
}

int netplay_unserialize_state(uint32_t size)
{
    if (frame_active)
        return 0;
    if (!retro_unserialize(savestate_buffer, size))
        return 0;
    netplay_refresh_state_hash();
    return 1;
}

void netplay_set_frame_active(int active)
{
    frame_active = active != 0;
}

uint64_t netplay_state_hash(void)
{
    uint64_t parts[3];
    rdram_hash = xxh64(g_rdram, RDRAM_MAX_SIZE,
                       UINT64_C(0x4e3634524452414d));
    cpu_hash = hash_cpu_state();
    rsp_hash = hash_rsp_state();
    parts[0] = rdram_hash;
    parts[1] = cpu_hash;
    parts[2] = rsp_hash;
    return xxh64(parts, sizeof(parts), UINT64_C(0x4e36345354415445));
}

void netplay_refresh_state_hash(void)
{
    state_hash = netplay_state_hash();
}

#define HASH_HALF_GETTERS(name, value) \
    uint32_t name##_low(void) { return (uint32_t)(value); } \
    uint32_t name##_high(void) { return (uint32_t)((value) >> 32); }

HASH_HALF_GETTERS(netplay_get_state_hash, state_hash)
HASH_HALF_GETTERS(netplay_get_rdram_hash, rdram_hash)
HASH_HALF_GETTERS(netplay_get_cpu_hash, cpu_hash)
HASH_HALF_GETTERS(netplay_get_rsp_hash, rsp_hash)

uint32_t netplay_get_rdram_size(void)
{
    return (uint32_t)g_dev.ri.rdram.dram_size;
}

const char* netplay_get_build_id(void)
{
    return "n64wasm-netplay-mvp-v1-cached-interpreter";
}

int netplay_corrupt_rdram(void)
{
    uint8_t* bytes;
    if (frame_active)
        return 0;
    bytes = (uint8_t*)g_rdram;
    bytes[0x1000] ^= 0x01;
    netplay_refresh_state_hash();
    return 1;
}
