#ifndef N64WASM_NETPLAY_H
#define N64WASM_NETPLAY_H

#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define NETPLAY_STATE_BUFFER_SIZE (16788288u + 1024u)

/* Canonical libretro save-state API for the active libretronew.c build. */
size_t retro_serialize_size(void);
bool retro_serialize(void* data, size_t size);
bool retro_unserialize(const void* data, size_t size);

/* These functions are only safe at an emulated frame boundary. */
uint32_t netplay_get_state_size(void);
uintptr_t netplay_get_state_buffer(void);
int netplay_serialize_state(void);
int netplay_unserialize_state(uint32_t size);
void netplay_set_frame_active(int active);

/* Direct canonical-state fingerprints. */
uint64_t netplay_state_hash(void);
void netplay_refresh_state_hash(void);
uint32_t netplay_get_state_hash_low(void);
uint32_t netplay_get_state_hash_high(void);
uint32_t netplay_get_rdram_hash_low(void);
uint32_t netplay_get_rdram_hash_high(void);
uint32_t netplay_get_cpu_hash_low(void);
uint32_t netplay_get_cpu_hash_high(void);
uint32_t netplay_get_rsp_hash_low(void);
uint32_t netplay_get_rsp_hash_high(void);

uint32_t netplay_get_rdram_size(void);
const char* netplay_get_build_id(void);
int netplay_corrupt_rdram(void);

/* Final N64 controller boundary, implemented by the input plugin. */
uint32_t netplay_capture_local_input(void);
void netplay_set_controller_input(unsigned player, uint32_t buttons,
                                  int stick_x, int stick_y);
void netplay_set_input_override(int enabled);

#ifdef __cplusplus
}
#endif

#endif
