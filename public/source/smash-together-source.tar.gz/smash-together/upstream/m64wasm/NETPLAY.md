# Generic netplay prototype

This is a minimum viable two-player delayed-lockstep implementation. Player 1
is the authoritative host and player 2 is the client. Both browsers execute
locally, but neither may run a frame until both frame-numbered inputs exist.
There is no rollback or input prediction.

## Build

The project currently targets Emscripten 2.0.7. Activate that SDK, then rebuild
the WASM exports:

```sh
source /path/to/emsdk/emsdk_env.sh
cd /path/to/N64Wasm/code
make clean
make
```

`make` writes `dist/n64wasm.js` and `dist/n64wasm.wasm`. A clean build is
important because the Makefile does not generate header dependency files.

Install and test the standalone relay (Node.js 18 or newer):

```sh
cd /path/to/N64Wasm/server/netplay
npm install
npm test
```

## Run

Terminal 1 — start the relay:

```sh
cd /path/to/N64Wasm/server/netplay
npm start
```

The default endpoint is `ws://localhost:5500/netplay`. Set `NETPLAY_PORT` to
change the port. The browser default can be changed with
`NETPLAY_SERVER_URL` in `dist/settings.js`.

Terminal 2 — serve the repository root so the development ROM is available
at `/smash.z64`:

```sh
cd /path/to/N64Wasm
python3 -m http.server 8000
```

Then perform the two-peer test:

1. Open `http://localhost:8000/dist/` in two windows or on two machines that
   can reach both the HTTP server and relay.
2. Select **Super Smash Bros.** and click **Play Game** in each window. This
   fetches `/smash.z64` from the HTTP server through the normal ROM loader.
   Imported save-memory files must also be identical.
3. In the host window, leave input delay at its default of 6 and click
   **Create Host**. The relay assigns the next numeric room ID.
4. Enter that room number in the other window, then click **Join Client**.
5. The peers verify ROM SHA-256, core build ID, graphics/core configuration,
   Expansion Pak/RDRAM size, active cheats, input delay, and the initial
   save-memory hash.
6. The host sends a complete binary save state. The client restores and
   verifies it before either peer begins netplay frame 0.
7. Use controller slot 1 in each browser. The host owns N64 player 1 and the
   client owns N64 player 2. Initial delay frames are neutral; subsequent
   input is submitted for `current_frame + input_delay`.

When serving the page over HTTPS, use a `wss://` relay endpoint or the browser
will block mixed content. ROM/save compatibility hashes use Web Crypto, so a
browser on another machine also needs the page served from an HTTPS secure
context; plain HTTP is supported by browsers only for localhost development.

## Deliberate desynchronization test

While both panels show `running`, click **Corrupt Client RDRAM** in the client
window. The same action is available from the client developer console:

```js
myApp.netplay.corruptClientRdram()
```

The button flips one byte at client RDRAM offset `0x1000` at a frame boundary.
On the next completed frame, the expected flow is:

```text
desync at frame N
received authoritative state for frame M
resynchronization successful
```

Both peers pause. The host serializes its current boundary state and sends the
complete state with boundary frame `M` and its hash. The client restores it,
discards inputs older than `M`, preserves future inputs, recalculates the
hash, acknowledges it, and both resume without a page reload. If the boundary
jumps past an unsent local input, each peer fills only that missing portion of
its delayed-input pipeline from its currently polled controller state.

Useful successful-session console messages include:

```text
connected
handshake successful
initial state loaded
frame 300 hash match
```

Hash matches are logged every 300 frames; input packets are not logged unless
`myApp.netplay.debugPackets` is set to `true`.

## Fingerprint and diagnostics

`netplay_state_hash()` uses an in-tree xxHash64 implementation over direct,
canonical emulator state rather than the serialized-state fallback:

- all 8 MiB of N64 RDRAM;
- MIPS general-purpose and floating-point registers, PC, HI/LO, CP0/FCR
  registers, LLBit, next event, and VI timing state;
- RSP DMEM, IMEM, and RSP registers.

The overall, RDRAM, CPU, and RSP hashes are available separately. State-hash
messages include the component hashes, and a mismatch logs both peers'
components. The panel also exposes executed/stalled frames, comparisons,
mismatches, repair bytes, restore outcomes, and average/maximum input wait.

The authoritative initial/repair snapshots always use the full output of
`retro_serialize()`. `retro_unserialize()` is guarded against use while a
frame is active.

## Prototype limitations

- Exactly two peers and one room-local host/client pair are supported.
- Inputs are delayed lockstep. A missing packet stalls emulation and can cause
  audio underruns; no previous input is reused.
- Save states are roughly 16 MiB and are sent uncompressed in one binary
  WebSocket message.
- The host may have advanced beyond the originally mismatched boundary by the
  time the client hash arrives. Repair therefore uses the host's current safe
  frame boundary and labels the snapshot with that boundary.
- Controller ownership is fixed: each browser samples its first local
  controller, mapped to host player 1 or client player 2.
- Reconnecting an interrupted session starts a new handshake and initial-state
  transfer; rooms are not persistent.
- This relay deliberately has no matchmaking, authentication, encryption,
  rate limiting, or production deployment hardening.
